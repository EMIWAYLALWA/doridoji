apt install python3-pip -y
pip install telebot --break-system-packages
chmod +x *
